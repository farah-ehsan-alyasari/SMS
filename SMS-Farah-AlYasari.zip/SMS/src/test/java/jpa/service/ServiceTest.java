package jpa.service;

import jpa.entitymodels.Student;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.platform.suite.api.SuiteDisplayName;

@SuiteDisplayName("Service testing") // Optional
public class ServiceTest {

    private static StudentService studentService;

    @BeforeAll
    public static void setUp()
    {
        studentService = new StudentServiceImpl();
    }

    @Test
    public void validateStudentTest(){

        //given
        Student trueStudent = new Student();

        //when
        trueStudent.setEmail("hluckham0@google.ru");
        trueStudent.setPassword("X1uZcoIh0dj");

        //then
        Assertions.assertEquals(true, studentService.validateStudent(trueStudent));

        //given
        Student falseStudent = new Student();

        //when
        falseStudent.setEmail("hluckham0@google.ru");
        falseStudent.setPassword("badPassword");

        //then
        Assertions.assertEquals(false, studentService.validateStudent(falseStudent));

    }

}
