package org.example;

import jpa.controller.CreateTables;
import jpa.controller.SMSRunner;
import jpa.dao.StudentDAO;
import jpa.entitymodels.Course;
import jpa.entitymodels.Student;
import jpa.service.CourseService;
import jpa.service.CourseServiceImpl;
import jpa.service.StudentService;
import jpa.service.StudentServiceImpl;

import java.util.List;

/**
 * Farah Al Yasari
 *
 */

/*
* Everything works except:
* When registeringStudentToCourse,
* Something in the Java code deletes the saved courses for the Student in the db
* and only adds one student that was recently added
* I tried my best to fix it, but i couldn't, i would appreciate if you can help me
* i really hope it will work
* */
public class App 
{
    public static void main( String[] args )
    {

        //data must be populated using SQL inside the database


        SMSRunner sms = new SMSRunner();
        sms.run();

        //StudentService studentService = new StudentServiceImpl();

        //Checking getAllStudents - It works

        /*
        List<Student> students = studentService.getAllStudents();
        for(Student student : students){
            System.out.println(student.getFullName());
        }*/

        //Checking getStudentByEmail - It works

        /*Student student = new Student();
        student = studentService.getStudentByEmail("hluckham0@google.ru");
        System.out.println(student.getFullName());*/

        //Checking validateStudent

        /*Student trueStudent = new Student();
        trueStudent.setEmail("hluckham0@google.ru");
        trueStudent.setPassword("X1uZcoIh0dj");
        Boolean res1 = studentService.validateStudent(trueStudent);
        System.out.println(res1);

        Student falseStudent = new Student();
        falseStudent.setEmail("hluckham0@google.ru");
        falseStudent.setPassword("wrongPassword");
        Boolean res2 = studentService.validateStudent(falseStudent);
        System.out.println(res2);*/

        //Checking registerStudentToCourse - It works
        //Note: course has to exist for a student to add it

        /*Student student = new Student();
        student.setEmail("hluckham0@google.ru");
        student.setPassword("X1uZcoIh0dj");
        student.setFullName("Hazel Luckham");
        Course course = new Course();
        course.setId(1);
        course.setName("English");
        Course course2 = new Course();
        course2.setId(2);
        course2.setName("Mathematics");
        course.setInstructor("Eustace Niemetz");
        studentService.registerStudentToCourse(student, course);*/

        //Checking getStudentCourses - It works

        /*Student student = new Student();
        student.setEmail("hluckham0@google.ru");
        student.setPassword("X1uZcoIh0dj");
        student.setFullName("Hazel Luckham");
        Course course = new Course();
        course.setId(1);
        course.setName("English");
        course.setInstructor("Anderea Scamaden");
        studentService.registerStudentToCourse(student, course);
        List<Course> courses = studentService.getStudentCourses(student);
        for(Course c: courses) {
            System.out.println(c.getName());
        }*/

        //Checking getAllCourses - It works

        /*CourseService courseService = new CourseServiceImpl();
        List<Course> courses = courseService.getAllCourses();
        for(Course course : courses){
            System.out.println(course.getName());
        }*/

    }
}
