package jpa.controller;

import jpa.entitymodels.Course;
import jpa.entitymodels.Student;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CreateTables {
    public  static void main(String args[]){
        SessionFactory factory = new Configuration().configure().buildSessionFactory();
        Session session = factory.openSession();
        Transaction t = session.beginTransaction();
        Student student = new Student();
        Course course = new Course();
        t.commit();
        System.out.println("successfully created table");
        factory.close();
        session.close();
    }
}