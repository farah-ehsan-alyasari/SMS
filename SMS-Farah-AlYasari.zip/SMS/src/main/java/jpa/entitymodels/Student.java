package jpa.entitymodels;
import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


@Entity
public class Student {

    @Id
    @GeneratedValue( strategy=GenerationType.IDENTITY )
    private String email;
    private String fullName;
    private String password;

    //Unidirectional many-to-many relationship between Student and Course
    @ManyToMany(targetEntity = Course.class)
    @JoinTable(name="student_course")
    private Set<Course> courses = new HashSet<Course>();

    public Student() {
    }

    public Student(String email, String fullName, String password, Set<Course> courses) {
        this.email = email;
        this.fullName = fullName;
        this.password = password;
        this.courses = courses;
        //courses = new ArrayList<Course>();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setCourses(Set<Course> courses) {
        this.courses = courses;
    }

    public Set<Course> getCourses() {
        return this.courses;
    }
}
