package jpa.dao;

import jpa.entitymodels.Course;
import jpa.entitymodels.Student;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import javax.persistence.TypedQuery;
import java.util.List;
import java.util.Set;

public class StudentDAOImpl implements StudentDAO {

    //The same SessionFactory instance must be used
    //for all methods, inorder for the program
    //to keep track of its context and changes made to the entities
    private final SessionFactory factory = new Configuration().configure().buildSessionFactory();


    @Override
    public List<Student> getAllStudents() {
        Session session = factory.openSession();
        Query query=session.createQuery("from Student");
        List<Student> results = query.getResultList();
        factory.close();
        session.close();
        return results;
    }

    @Override
    public Student getStudentByEmail(String email) {
        Session session = factory.openSession();

        String hql = "FROM Student s where s.email =:email";
        TypedQuery<Student> query = session.createQuery(hql, Student.class);
        query.setParameter("email",email);

        /*
        * Cannot use this because an exception will be thrown
        * in the case more than one student with the same email
        * are given back. Although I don't think it will be
        * a problem because email is the primary key, and
        * by definition the primary key is unique.
        * but i am going to use getResultList() to keep this note
        * to myself for future reference
        * Student student = (Student) query.getSingleResult();*/

        List<Student> resultList = query.getResultList();

        factory.close();
        session.close();

        if(resultList.isEmpty()){
            return null;
        }

        return resultList.get(0);
    }

    //validation approach: given student.password and student.email, checks if student exists in db
    @Override
    public Boolean validateStudent(Student student) {
        Session session = factory.openSession();

        String hql = "FROM Student s WHERE s.email =: email and s.password =: password";
        TypedQuery<Student> query = session.createQuery(hql, Student.class);
        query.setParameter("email", student.getEmail());
        query.setParameter("password", student.getPassword());

        //ideally: there should be something here to catch an exception
        //when the result set is empty. But there isn't because I just focused on core functionality
        //which means data needs to be in the database first for the app to run
        List<Student> resultList = query.getResultList();

        factory.close();
        session.close();

        //resultList.isEmpty is false if student was found with such credentials
        //resultList.isEmpty is true if no student was found with such credentials
        //therefore, return !resultList.isEmpty();
        return !resultList.isEmpty();
    }

    @Override
    public void registerStudentToCourse(Student student, Course course) {
        Session session = factory.openSession();

        //need a transaction because this is a write-operation to db
        Transaction t = session.beginTransaction();

        Set<Course> courses = student.getCourses();
        courses.add(course);
        student.setCourses(courses);

        session.saveOrUpdate(student);

        t.commit();

        factory.close();
        session.close();
    }

    @Override
    public List<Course> getStudentCourses(Student student) {

        Session session = factory.openSession();

        String hql = "SELECT s.courses FROM Student s WHERE s.email =: email";
        Query query = session.createQuery(hql);
        query.setParameter("email", student.getEmail());
        List<Course> courses = query.getResultList();

        factory.close();
        session.close();

        return courses;
    }
}
