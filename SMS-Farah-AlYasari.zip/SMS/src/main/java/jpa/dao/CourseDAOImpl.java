package jpa.dao;

import jpa.entitymodels.Course;
import jpa.entitymodels.Student;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.List;

public class CourseDAOImpl implements CourseDAO{

    @Override
    public List<Course> getAllCourses() {
        SessionFactory factory = new Configuration().configure().buildSessionFactory();
        Session session = factory.openSession();
        Query query=session.createQuery("from Course");
        List<Course> results = query.getResultList();
        factory.close();
        session.close();
        return results;
    }

}
