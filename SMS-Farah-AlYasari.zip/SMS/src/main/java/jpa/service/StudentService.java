package jpa.service;

import jpa.entitymodels.Course;
import jpa.entitymodels.Student;

import java.util.List;

public interface StudentService {

    List<Student> getAllStudents();

    Student getStudentByEmail(String email);

    Boolean validateStudent(Student student);

    void  registerStudentToCourse(Student student, Course course);

    List<Course> getStudentCourses(Student student);

}
