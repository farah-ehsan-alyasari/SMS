package jpa.service;

import jpa.dao.CourseDAO;
import jpa.dao.CourseDAOImpl;
import jpa.entitymodels.Course;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import javax.persistence.TypedQuery;
import java.util.List;

public class CourseServiceImpl implements  CourseService{

    @Override
    public List<Course> getAllCourses() {
        CourseDAO coursedao = new CourseDAOImpl();
        return coursedao.getAllCourses();
    }

    @Override
    public Course getCourseById(int id) {
        SessionFactory factory = new Configuration().configure().buildSessionFactory();
        Session session = factory.openSession();

        String hql = "FROM Course c where c.id =: id";
        TypedQuery<Course> query = session.createQuery(hql, Course.class);
        query.setParameter("id",id);

        List<Course> resultList = query.getResultList();

        factory.close();
        session.close();

        if(resultList.isEmpty()){
            return null;
        }

        return resultList.get(0);
    }
}
