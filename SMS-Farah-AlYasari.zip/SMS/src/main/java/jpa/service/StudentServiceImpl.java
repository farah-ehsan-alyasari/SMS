package jpa.service;

import jpa.dao.StudentDAO;
import jpa.dao.StudentDAOImpl;
import jpa.entitymodels.Course;
import jpa.entitymodels.Student;

import java.util.List;

public class StudentServiceImpl implements  StudentService{



    @Override
    public List<Student> getAllStudents() {
        StudentDAO studentdao = new StudentDAOImpl();
        List<Student> students = studentdao.getAllStudents();
        return students;
    }

    @Override
    public Student getStudentByEmail(String email) {
        StudentDAO studentdao = new StudentDAOImpl();
        Student student = studentdao.getStudentByEmail(email);
        return student;
    }

    @Override
    public Boolean validateStudent(Student student) {
        StudentDAO studentdao = new StudentDAOImpl();
        Boolean result = studentdao.validateStudent(student);
        return result;
    }

    @Override
    public void registerStudentToCourse(Student student, Course course) {
        StudentDAO studentdao = new StudentDAOImpl();
        studentdao.registerStudentToCourse(student, course);
    }

    @Override
    public List<Course> getStudentCourses(Student student) {
        StudentDAO studentdao = new StudentDAOImpl();
        List<Course> studentCourses = studentdao.getStudentCourses(student);
        return studentCourses;
    }
}
